# import rsa
# import math

# # Tạo cặp khóa RSA với độ dài 1024 bit
# (pub_key_default, priv_key_default) = rsa.newkeys(2048)
# n = pub_key_default.n  # Sử dụng cùng mô-đun n
# message = 'Trade what you see not what you think'.encode('utf-8')

# # Tạo khóa công khai với e = 3 và e = 65537
# pub_key_e3 = rsa.PublicKey(n, 3)
# pub_key_e65537 = rsa.PublicKey(n, 65537)

# # Hàm kiểm tra nguyên tố cùng nhau
# def is_coprime(a, b):
#     return math.gcd(a, b) == 1

# # Hàm mã hóa và kiểm tra xem bản mã có nguyên tố cùng nhau với n không
# def encrypt_and_check_coprime(message, pub_key, n):
#     while True:
#         # Mã hóa thông điệp
#         ciphertext = rsa.encrypt(message, pub_key)
#         # Chuyển bản mã sang hệ 10
#         ciphertext_decimal = int.from_bytes(ciphertext, byteorder='big')
        
#         # Kiểm tra xem bản mã và n có nguyên tố cùng nhau không
#         if is_coprime(ciphertext_decimal, n):
#             return ciphertext_decimal
#         else:
#             print(f"Ciphertext không nguyên tố cùng nhau với n. Mã hóa lại...")
            
# # Mã hóa thông điệp với e = 3 và kiểm tra nguyên tố cùng nhau
# ciphertext_e3_decimal = encrypt_and_check_coprime(message, pub_key_e3, n)

# # Mã hóa thông điệp với e = 65537 và kiểm tra nguyên tố cùng nhau
# ciphertext_e65537_decimal = encrypt_and_check_coprime(message, pub_key_e65537, n)
# # ciphertext = rsa.encrypt(message, pub_key_e3)
# # print(ciphertext)
# # Hiển thị kết quả
# print(n)
# print("Ciphertext (hệ 10) với e = 3 (nguyên tố cùng nhau với n):", ciphertext_e3_decimal)
# print("Ciphertext (hệ 10) với e = 65537 (nguyên tố cùng nhau với n):", ciphertext_e65537_decimal)
# import rsa

# # Tạo cặp khóa RSA với mô-đun n nhỏ (ví dụ cho đơn giản)
# (pub_key_default, priv_key_default) = rsa.newkeys(2048)
# n = pub_key_default.n  # Sử dụng cùng mô-đun n

# # n = 3233  # Mô-đun RSA (ví dụ nhỏ)
# e1 = 3  # Số mũ e1
# e2 = 7  # Số mũ e2

# # Tạo khóa công khai từ n và các số mũ e1, e2
# pub_key_e1 = rsa.PublicKey(n, e1)
# pub_key_e2 = rsa.PublicKey(n, e2)

# # Thông điệp cần mã hóa, cần đảm bảo nó nhỏ hơn mô-đun n
# message = 'He'.encode('utf-8')  # Thông điệp nhỏ hơn để mã hóa thành công

# # Mã hóa thông điệp với e1 và e2
# ct1 = rsa.encrypt(message, pub_key_e1)
# ct2 = rsa.encrypt(message, pub_key_e2)

# # In ra các bản mã (ct1 và ct2) dưới dạng số nguyên
# ct1_int = int.from_bytes(ct1, byteorder='big')
# ct2_int = int.from_bytes(ct2, byteorder='big')
# print(n)
# print(f"Ciphertext ct1 (e1 = {e1}):", ct1_int)
# print(f"Ciphertext ct2 (e2 = {e2}):", ct2_int)

# import rsa

# # Tạo cặp khóa RSA với độ dài 1024 bit
# (pub_key, priv_key) = rsa.newkeys(1024)

# # In khóa công khai (n, e)
# print("Khóa công khai:")
# print(f"n (modulus): {pub_key.n}")
# print(f"e (exponent): {pub_key.e}")

# print(pub_key)
# # Lưu khóa công khai vào file (tùy chọn)
# with open("public_key.pem", "wb") as pub_file:
#     pub_file.write(pub_key.save_pkcs1())

# print("\nKhóa công khai đã được lưu vào 'public_key.pem'.")
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

def create_pem_public_key(n: int, e: int) -> str:
    # Tạo đối tượng public key từ n và e
    public_numbers = rsa.RSAPublicNumbers(e, n)
    public_key = public_numbers.public_key()

    # Xuất khóa ra định dạng PEM
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    return pem.decode('utf-8')  # Trả về chuỗi PEM

# Ví dụ với e và n
e = 11
# n = 0xd4eb16f1c1b739d8d86563a2af5e12dfe20e76b24b7f52b6769e2f8e9c4f9ffdf0f6f58b2313a8e6c9dfb1f6a80b616fc845c9b3b594e6c1fa7fa5cd25bb6e71
n=0xc3206740914692ccb4f9b603a88808c22a23ee3e997ced3f92a0c1259cfb6d9eaec2079dc7d4db05daf0cd85ca403af57c82127b33959de12ad38afa27826a28b6390452feed05b9410a9b3faca6dded4bff192e67db4d415f7f47939c6749f0be228a11357bfe16ba703e557182432fa945631faed39afa63046037a403b833e67bbe8f6f55b5001d87fc4aca73f145dbdf3fdaf8251f1a94cc05247a3c231d2c454ad1b0399a4e7500734a83cc88a98cf17f3fe99ee43d97d830b4f047790a85217442ccf4fb0bc51fbee1f5b60b815ee273466cbb18b1154741f6217e40691d4324de4cb40f866ec00300d8d43652abb84c6cb2f5a82c6645d4fabe30b698237d96ecd6175617b5de8e46e4daf703719324443608019136191b086670fb77f0998ab175e943452bd38610736e8b62319ec21c650cfcedcf8963c0902fcc07f3bc4a835a61765d0c01368ac284ca12e4d193e600a4f5fdc900c5d7c3cfac89252f4d4fa0a9bb9eb53938d48d65336a78ce384f3de31796b1126f77220dbbde370f74cd811d5f0ecf383167be8b7518b55c34123141b00e3c121145b61d6b17ec25ddadafcd93209d18701e7ebac270c006badf50473267420d7ba4fbe085877c8884fd055209cb49120740122af2ca8724807032ccef5aa486709a7363c0ca259b4eb3cc81c854cfeb60ec648de77c79ae764a6f5016552aaf1e08256c23e9
pem_key = create_pem_public_key(n, e)
print(pem_key)

# p = 0x00E5B5B1EDC8DF0F307C2220151CFCBE31F69B15659A5D6FBA1E50F55A08B341218312D707CFC16ED86A1765F5AEAFA7E6A11C4431038914C76F0F398FE6BE031E289B220D13D9E02226C691D15BC6E1186EA18222D93F52A393BE1DA1A42853512419B5E6E304FD02E962A4C2D0ECDDB8F44AC094FACA8333AE94110A5B10DA539C24A96F08530E7699E3F705165CF14B7F90A2F32ED28D21615F91D7C808AC566D6EEEF6773450AB53542CDAC337C3124530CB16319752267C3422149D41543D8742586BAB578F4E06360745AE0BD8F0E800D1920DC1F3661287367A78967458383A82465C5D966E7299EFCF58BD860185F96655E1F8D300F6B096DFE883CF15
# q = 0x00D9757338E9A6B363F227F3104EDEF6240C0CAF53B7D509F48870553C4A821F460469AE5616301B9CC30FBF4598A176B84284AF3A41D697A34CDC2C8D88A4C4BE82AE8DB5347511FE5B4DD915CA6A728CCFD0444CE38FC7190824059D86A9083C273581EA5AD1D5E3A8D8EC6858F291A5EADA98B0F5FD7C8E8CA6226657B8B7955796B22899B087714E293A86C78D42A7021754A6220F1D0A9588C280DD9AEC376E421D539F30A3053D95C7D70F24B471D14ECF282FA3E0B1CED2C405BA22404F3B75CD961A46097D7C098324FC47281D298734DA0DFCD8AF82E685657C926672727296147867EAEDFDEF89A79DE81FF104CF7D9157EF65A1BC333C98A7FED685
# print(hex(p*q))