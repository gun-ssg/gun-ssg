def extended_gcd(a, b):
    """
    Thuật toán Euclid mở rộng để tìm gcd(a, b) và các hệ số x, y
    sao cho: a * x + b * y = gcd(a, b)
    
    :param a: Số nguyên a
    :param b: Số nguyên b
    :return: (gcd, x, y)
    """
    if b == 0:
        return a, 1, 0  # gcd(a, 0) = a và x = 1, y = 0
    else:
        gcd, x1, y1 = extended_gcd(b, a % b)
        # Cập nhật x, y theo công thức
        x = y1
        y = x1 - (a // b) * y1
        return gcd, x, y

# Ví dụ sử dụng:
a = 1540
b = 13
gcd, x, y = extended_gcd(a, b)
print(f"GCD({a}, {b}) = {gcd}")
print(f"x = {x}, y = {y}")
print(f"Kiểm tra: {a} * {x} + {b} * {y} = {gcd}")
