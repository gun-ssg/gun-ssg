#!/usr/bin/python

# This program prepares test keys to demonstrate the use of rsa-common-modulus.py
# It outputs a sample command line for the rsa-common-modulus.py
# You can just execute the produced output

import sys

from gmpy2 import is_prime, lcm, gcd, invert

def test_e(arg_e, arg_lam, arg_n):
    if arg_e <= 1 or arg_e >= arg_lam or arg_e >= arg_n or gcd(arg_e, arg_n) != 1:
        print("Invalid e!")
        sys.exit(1)


def int_to_bytes(arg_message):
    return int.to_bytes(
        arg_message, (arg_message.bit_length() + 7) // 8, byteorder="big"
    )


def main():

    text = 'PTIT'
    binary = text.encode("ascii")
    plaintext = int.from_bytes(binary, byteorder="big", signed=False)
    plaintext_len_bits = int.bit_length(plaintext)
    # p = 0xa2baec8ad1f0e6ac6d99016f627860c938e19de8a0b1b74336a53ca83d8cf3db#512 bit
    # q = 0xe858aefb7086f2e707769f3663df906ae97787c781205afc9c88bb208a476d59
    # p = 0xf42ddbd29eac78f78f7ea6bb8e592315#256bit
    # q = 0xac15901ac700a80a0e6d6475def60ccb
    p= 0xfd3f0e3b#64bit
    q= 0xe57f8adb
    if not is_prime(p):
        print("p is not a prime!")
        sys.exit(1)

    if not is_prime(q):
        print("q is not a prime!")
        sys.exit(1)

    # prepare keys
    n = p * q
    modulus_len_bits = int.bit_length(n)

    pm1 = p - 1
    qm1 = q - 1
    lam = lcm(pm1, qm1)
    e1 = 3
    e2 = 65537
    test_e(e1, lam, n)
    test_e(e2, lam, n)
    d1 = invert(e1, lam)
    d2 = invert(e2, lam)

    # produce ciphertexts
    if plaintext_len_bits > modulus_len_bits:
        print(
            "Plaintext is too long for this modulus! Plaintext:",
            plaintext_len_bits,
            "bits, modulus:",
            modulus_len_bits,
            "bits!",
        )
        sys.exit(1)

    c1 = pow(plaintext, e1, n)
    c2 = pow(plaintext, e2, n)

    # verify ciphertexts
    m1 = pow(c1, d1, n)
    m2 = pow(c2, d2, n)

    if m1 != plaintext or m2 != plaintext:
        print(int_to_bytes(plaintext))
        print(int_to_bytes(m1))
        print(int_to_bytes(m2))
        sys.exit(1)

    output = "./rsa-common-modulus.py --modulus {n} --e1 {e1} --ct1 {ct1} --e2 {e2} --ct2 {ct2} --outputformat ascii --quiet".format(
        n=n, e1=e1, ct1=c1, e2=e2, ct2=c2
    )
    print(output)


main()
