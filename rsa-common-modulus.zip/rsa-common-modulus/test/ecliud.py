import math
import sys
import decimal
from sympy import factorint

def extended_gcd(a, b):
    if b == 0:
        return a, 1, 0  
    else:
        gcd, x1, y1 = extended_gcd(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return gcd, x, y
def attack(c, e1, e2,d2, N):
    t=d2*e2-1
    d1=0
    gcd,r,s=extended_gcd(t,e1)
    while(gcd!=1):
        t=t//gcd
        gcd,r,s=extended_gcd(t,e1)
    d1=s
    m=pow(c,d1,N)
    return m
def check(m,e,n,c):
    c1=pow(m,e,n)
    return c1==c




def find_snt(a):
    factors = factorint(a)  # Phân tích số nguyên tố
    primes = list(factors.keys())
    if len(primes) == 2:  # Kiểm tra nếu có đúng 2 thừa số nguyên tố
        return primes[0], primes[1]
    else:
        raise ValueError("Số không phải là tích của đúng hai số nguyên tố.")
c = 14451373113727066590
e1 = 3
e2 = 65537
n = 16359206209705867897
# c = 27
# n = 253
# e1 = 13
# e2 = 7

# Phân tích n thành p, q
p, q = find_snt(n)
# p = 324569742864878005986556386894696489749
# q = 228739176297538223228591609687590702283
print(q,p)
phi_n = (p - 1) * (q - 1)

# Tính d2
d2 = pow(e2, -1, phi_n)
print(d2)
# Tấn công
m = attack(c, e1, e2, d2, n)
print("Thông điệp giải mã:", m)

# Kiểm tra kết quả
if check(m, e1, n, c):
    print("Giải mã thành công!")
else:
    print("Giải mã thất bại.")
