from sympy import randprime
import rsa
import math
from gmpy2 import is_prime, lcm, gcd, invert

e1=3
e2=65537
def generate_m_bit_n(m):
    k=m/2
    while True:
        q = randprime(2**(k-1), 2**k)
        p = randprime(2**(k-1), 2**k)
        if (is_prime(p) and is_prime(q)):
            break
    n = p * q

    while n.bit_length() != m:
        p = randprime(2**(k-1), 2**k)
        q = randprime(2**(k-1), 2**k)
        n = p * q
    
    return p, q, n

def find_valid_modulus(m):
    while True:
        try:
            p,q,n=generate_m_bit_n(m)
            inverse = invert(e1, lcm(p-1,q-1))
            return p,q,n
        except ZeroDivisionError:
            print("Giá trị x không hợp lệ! Vui lòng nhập lại .")
        except ValueError:
            print("Vui lòng nhập một số nguyên hợp lệ.")

# Gọi hàm

# m=int(input("M : "))
m=64
# p, q, n = generate_m_bit_n(m)

p,q,n=find_valid_modulus(m)
# In kết quả
print(f"p: {p}")
print(f"q: {q}")
print(f"n: {n}")


print(f"p: {hex(p)}")
print(f"q: {hex(q)}")
print(f"n: {hex(n)}")
print(f"Độ dài của n (bit): {n.bit_length()}")
public_key1 = rsa.PublicKey(n, e1)
public_key2 = rsa.PublicKey(n, e2)
print(public_key1)
print(public_key2)
with open("public_key1.pem", "wb") as pub_file:
    pub_file.write(public_key1.save_pkcs1())
with open("public_key2.pem", "wb") as pub_file:
    pub_file.write(public_key2.save_pkcs1())