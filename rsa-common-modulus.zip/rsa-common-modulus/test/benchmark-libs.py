#!/usr/bin/python

import sys
import math
import time
import secrets

from gmpy2 import is_prime, invert
from gmpy2 import gcd as gmpy2_gcd
from gmpy2 import version as gmpy2_version
from gmpy2 import powmod as gmpy2_powmod


def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)


def modinv_egcd(a, b):
    g, x, y = egcd(a, b)
    if g != 1:
        print("Modular inverse does not exist!", file=sys.stderr)
        sys.exit(1)
    else:
        return x % b


def modinv_pow(a, b):
    return pow(a, -1, b)


def modinv_gmpy(a, b):
    return invert(a, b)


def call_lcm(a, b):
    if "lcm" in dir(math):
        return math.lcm(a, b)
    else:
        return abs(a * b) // math.gcd(a, b)


def invalid_e(arg_e, arg_lam, arg_n):
    return (
        arg_e <= 1 or arg_e >= arg_lam or arg_e >= arg_n or math.gcd(arg_e, arg_n) != 1
    )


def main():
    print("Executing the benchmarks. Please wait...")

    p = 0xa2baec8ad1f0e6ac6d99016f627860c938e19de8a0b1b74336a53ca83d8cf3db
    q = 0xe858aefb7086f2e707769f3663df906ae97787c781205afc9c88bb208a476d59
    if not is_prime(p):
        print("p is not a prime!")
        sys.exit(1)
    if not is_prime(q):
        print("q is not a prime!")
        sys.exit(1)
    n = p * q
    pm1 = p - 1
    qm1 = q - 1
    lam = call_lcm(pm1, qm1)
    e = 65537
    if invalid_e(e, lam, n):
        print("Invalid e!")
        sys.exit(1)

    e_len_bits = int.bit_length(e)
    e_len_bytes = (e_len_bits + 7) // 8
    message_bytes = secrets.token_bytes(e_len_bytes - 1)
    m = int.from_bytes(message_bytes, byteorder="big", signed=False)

    c = pow(m, e, n)

    counter = 100000

    start_egcd = time.time()
    for i in range(counter):
        d = modinv_egcd(e, lam)
    end_egcd = time.time()
    elapsed_egcd = end_egcd - start_egcd

    m2 = pow(c, d, n)
    if m2 != m:
        print("Message mismatch error on egcd")
        sys.exit(1)

    start_pow = time.time()
    for i in range(counter):
        d = modinv_pow(e, lam)
    end_pow = time.time()
    elapsed_pow = end_pow - start_pow

    m2 = pow(c, d, n)
    if m2 != m:
        print("Message mismatch error on pow")
        sys.exit(1)

    start_gmpy = time.time()
    for i in range(counter):
        d = modinv_gmpy(e, lam)
    end_gmpy = time.time()
    elapsed_gmpy = end_gmpy - start_gmpy

    m2 = pow(c, d, n)
    if m2 != m:
        print("Message mismatch error on gmpy")
        sys.exit(1)

    start_g_gcd = time.time()
    for i in range(counter):
        d = gmpy2_gcd(pm1, qm1)
    end_g_gcd = time.time()
    elapsed_g_gcd = end_g_gcd - start_g_gcd

    start_m_gcd = time.time()
    for i in range(counter):
        d = math.gcd(pm1, qm1)
    end_m_gcd = time.time()
    elapsed_m_gcd = end_m_gcd - start_m_gcd

    start_g_pow = time.time()
    for i in range(counter):
        m2 = gmpy2_powmod(c, d, n)
    end_g_pow = time.time()
    elapsed_g_pow = end_g_pow - start_g_pow

    start_m_pow = time.time()
    for i in range(counter):
        m2 = pow(c, d, n)
    end_m_pow = time.time()
    elapsed_m_pow = end_m_pow - start_m_pow



    print("modinv egcd:", elapsed_egcd)
    print(" modinv pow:", elapsed_pow)
    print("modinv gmpy:", elapsed_gmpy)

    print("gcd gmpy:", elapsed_g_gcd)
    print("gcd math:", elapsed_m_gcd)

    print("pow gmpy:", elapsed_g_pow)
    print("pow math:", elapsed_m_pow)


    print("gmpy2 version:", gmpy2_version())
    print("Python version:", sys.version)


main()
